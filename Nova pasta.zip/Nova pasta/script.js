function mostrar(secaoId) {
  const secoes = document.querySelectorAll('.conteudo');
  secoes.forEach(secao => secao.style.display = 'none');

  const ativa = document.getElementById(secaoId);
  if (ativa) {
    ativa.style.display = 'block';
  }
}

// Mostrar "campo" por padrão
window.onload = () => mostrar('campo');
